import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Panel extends JPanel implements ActionListener{
    private int[][] field;
    public static final int SIZE = 32;
    private int score;

    private static Image BACKGROUND = new ImageIcon("images/BACKGROUND.png").getImage();
    private static Image nextPent = new ImageIcon(getPicture(TetrisGame.nextx)).getImage();


    public Panel(){
        field = new int[5][15];
        score = TetrisGame.fullscore;
        this.setLayout(null);
    }


    @Override
    public void paintComponent(Graphics g){
        g.drawImage(BACKGROUND, 0, 0, null);
        g.setFont(new Font("Comic Sans MS", Font.BOLD, 46));
        g.setColor(Color.MAGENTA);
        g.drawString(score+"", 70, 140);
        
        drawPent(g);

        g.drawImage(nextPent, 560, 368, null);        
    }

    public void drawPent(Graphics g){
        for(int i = 0; i < field.length; i++){
            for(int j = 0; j < field[0].length; j++){
                if(field[i][j] == -1){
                    continue;
                }
                Image pentDraw = new ImageIcon(field[i][j] + ".png").getImage();
                g.drawImage(pentDraw, i * SIZE + 280, j * SIZE + 32, null);
            }
        }
        
    }

    

    public void setState(int[][] field) {
        this.field = field;
        this.score = TetrisGame.fullscore;
        this.nextPent = new ImageIcon(getPicture(TetrisGame.nextx)).getImage();
        repaint();
    }

    @Override
    public void actionPerformed(ActionEvent keyboard) {
        String action = keyboard.getActionCommand();

         if (action.equals("Left")) {
            TetrisGame.moveLeft();
         }
         if (action.equals("Right")) {
            TetrisGame.moveRight();
         }
         if (action.equals("Rotate")) {
            TetrisGame.rotate();
         }
         if (action.equals("Space")) {
            TetrisGame.rotate();
        }
        
    }

    public static String getPicture(int a){
        String nextpicture = "";
        switch(TetrisGame.nextx){
            case 0:
                nextpicture="X.png";
                break;
            case 1:
                nextpicture="I.png";
                break;
            case 2:
                nextpicture="Z.png";
                break;
            case 3:
                nextpicture="T.png";
                break;
            case 4:
                nextpicture="U.png";
                break;
            case 5:
                nextpicture="V.png";
                break;
            case 6:
                nextpicture="W.png";
                break;
            case 7:
                nextpicture="Y.png";
                break;
            case 8:
                nextpicture="L.png";
                break;
            case 9:
                nextpicture="P.png";
                break;
            case 10:
                nextpicture="N.png";
                break;
            case 11:
                nextpicture="F.png";
                break;
        }
        return nextpicture;
    }

    


}