import java.util.ArrayList;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

public class TetrisGame {
    public static Frame frame = new Frame();
    public static int[][] field = new int[5][15];
    public static int[][] backgroundfield = copyOf(field);
    public static Scanner scan = new Scanner(System.in);
    public static ArrayList<Integer> a = new ArrayList<>();
    public static ArrayList<int[]> squareswithsameID = new ArrayList<>();
    public static ArrayList<int[]> squareswithsameID2 = new ArrayList<>();
    public static int p = 0;
    public static int m = 0;
    public static int n = 0;
    public static int previousn = 0;
    public static int placeinarray = 0;
    public static int currentplaceinarray = 0;
    public static int x = (int) (Math.random() * 12);
    public static int nextx = (int) (Math.random() * 12);
    public static int[][] oldfield;
    public static int[] botarray = new int[3];
    public static boolean botplays = false;
    //public static Frame frame;

    public static void game() {
        simpleRuleBasedBot bot = new simpleRuleBasedBot();
        a.add(x);
        oldfield = copyOf(field);
        TimerTask move = new TimerTask() {
            @Override
            public void run() {
                //if (botplays) {
                    if (placeinarray == currentplaceinarray)
                        bot.step();
                    bot.movements();
                //}
                currentplaceinarray++;
                int[][] pieceToPlace = PentominoDatabase.data[x][p];
                if (canPut(pieceToPlace, x, m, n, oldfield)) {
                    if (n - 1 >= 0) {
                        field = copyOf(oldfield);
                    }
                    oldfield = copyOf(field);
                    addPiece(field, x, pieceToPlace, x, m, n);
                    frame.panel.setState(field);
                    n++;
                    previousn = n;

                }

                else {
                    if (!canPut(pieceToPlace, x, 0, 0, oldfield)) {
                        System.out.println("Game over!");
                        System.out.println("Your score is: " + fullscore);
                        System.exit(0);
                    }
                    frame.panel.setState(field);
                    addPiece(backgroundfield, placeinarray, pieceToPlace, placeinarray, m, n - 1);
                    while (FullRowExists(backgroundfield)) {
                        removeFullRow(backgroundfield);
                        frame.panel.setState(field);
                        while (candropdown(backgroundfield)) {

                        }

                    }
                    field = translating(backgroundfield);
                    placeinarray++;
                    currentplaceinarray = placeinarray;
                    n = 0;
                    m = 0;
                    p = 0;
                    removeFullRow(field);
                    frame.panel.setState(field);
                    x = nextx;
                    nextx = (int) (Math.random() * 12);
                    a.add(x);
                    if (!canPut(pieceToPlace, x, 0, 0, oldfield)) {
                        System.out.println("Game over!");
                        System.out.println("Your score is: " + fullscore);
                        System.exit(0);
                    }
                }
            }

        };
        Timer newmove = new Timer();
        newmove.schedule(move, 50, (long) Math.floor(1000 / 2f));
    }

    public static void main(String[] args) {
        for (int i = 0; i < field.length; i++) {
            for (int j = 0; j < field[i].length; j++) {
                field[i][j] = -1;
                backgroundfield[i][j] = -1;
            }
        }
        game();

    }

    public static void addPiece(int[][] field, int pentID, int[][] piece, int pieceID, int x, int y) {
        for (int i = 0; i < piece.length; i++) {
            for (int j = 0; j < piece[i].length; j++) {
                if (piece[i][j] == 1) {
                    field[x + i][y + j] = pieceID;
                }
            }
        }
    }

    public static boolean outOfTheBounds(int[][] pieceToPlace, int pentID, int x, int y, int[][] field) {
        int t = x;
        if (field.length < (x + pieceToPlace.length)) {
            return false;
        }
        if (field[0].length < (y + pieceToPlace[0].length)) {
            return false;
        }
        if (t - x > x + 1) {
            return false;

        }

        return true;
    }

    public static boolean canPut(int[][] pieceToPlace, int pentID, int x, int y, int[][] field) {
        if (!outOfTheBounds(pieceToPlace, pentID, x, y, field)) {
            return false;
        }

        for (int a = 0; a < pieceToPlace.length; a++) {
            for (int b = 0; b < pieceToPlace[0].length; b++) {
                if (pieceToPlace[a][b] == 1) {
                    if (field[x + a][y + b] != -1) {
                        return false;
                    }
                }

            }

        }
        return true;
    }

    public static int[][] copyOf(int[][] field) {
        int[][] newfield = new int[field.length][field[0].length];
        for (int a = 0; a < field.length; a++) {
            for (int b = 0; b < field[0].length; b++) {
                newfield[a][b] = field[a][b];
            }
        }
        return newfield;
    }

    public static int fullscore = 0;

    public static boolean FullRowExists(int[][] field1) {
        int counter = 0;
        for (int i = 14; i >= 0; i--) {
            counter = 0;
            for (int j = 0; j < field1.length; j++) {
                if (field1[j][i] != -1) {
                    counter++;
                }
            }
            if (counter == field1.length) {
                return true;
            }
        }
        return false;
    }

    public static void removeFullRow(int[][] field1) {
        int counter = 0;
        for (int i = 14; i >= 0; i--) {
            counter = 0;
            for (int j = 0; j < field1.length; j++) {
                if (field1[j][i] != -1) {
                    counter++;
                }
            }
            if (counter == field1.length) {
                for (int k = 0; k < field1.length; k++) {
                    field1[k][i] = -1;
                }
                fullscore++;
            }
        }
    }

    public static void FloodFill(int x, int y, int[][] field2, int v) {
        if (field2[x][y] == -1) {
            return;
        }
        int[][] field1 = copyOf(field2);
        field1[x][y] = -1;
        int[] koordinates = new int[] { x, y };

        squareswithsameID.add(koordinates);
        if (x - 1 >= 0) {
            if (field1[x - 1][y] == v) {
                FloodFill(x - 1, y, field1, v);
            }
        }
        if (y - 1 >= 0) {
            if (field1[x][y - 1] == v) {
                FloodFill(x, y - 1, field1, v);
            }
        }
        if (x + 1 < field1.length) {
            if (field1[x + 1][y] == v) {
                FloodFill(x + 1, y, field1, v);
            }
        }
        if (y + 1 < field1[0].length) {
            if (field1[x][y + 1] == v) {
                FloodFill(x, y + 1, field1, v);
            }
        }
        return;

    }

    public static void FloodFill2(int x, int y, int[][] field2, int v) {
        if (field2[x][y] == -1) {
            return;
        }
        int[][] field1 = copyOf(field2);
        field1[x][y] = -1;
        int[] koordinates2 = new int[] { x, y };
        squareswithsameID2.add(koordinates2);
        if (x - 1 >= 0) {
            if (field1[x - 1][y] == v) {
                FloodFill2(x - 1, y, field1, v);
            }
        }
        if (y - 1 >= 0) {
            if (field1[x][y - 1] == v) {
                FloodFill2(x, y - 1, field1, v);
            }
        }
        if (x + 1 < field1.length) {
            if (field1[x + 1][y] == v) {
                FloodFill2(x + 1, y, field1, v);
            }
        }
        if (y + 1 < field1[0].length) {
            if (field1[x][y + 1] == v) {
                FloodFill2(x, y + 1, field1, v);
            }
        }
        return;
    }

    public static boolean candropdown(int[][] field2) {
        int[][] field1 = copyOf(field2);
        for (int q = 14; q >= 0; q--) {
            for (int w = 0; w < field1.length; w++) {
                if (field1[w][q] != -1) {
                    int v = field1[w][q];
                    squareswithsameID.clear();
                    FloodFill(w, q, field1, v);
                    int brojac = 0;
                    for (int arraylist = 0; arraylist < squareswithsameID.size(); arraylist++) {
                        if (squareswithsameID.get(arraylist)[1] + 1 < field1[0].length && (field1[squareswithsameID
                                .get(arraylist)[0]][squareswithsameID.get(arraylist)[1] + 1] == -1
                                || field1[squareswithsameID.get(arraylist)[0]][squareswithsameID.get(arraylist)[1]
                                        + 1] == v)) {
                            brojac++;
                        }
                    }
                    int brojac2 = 0;
                    if (a.get(v) == 4 && p % 2 == 1 && squareswithsameID.size() == 5) {
                        int v1 = 0;
                        if (q > 0 && w + 1 < field1.length) {
                            if (field1[w][q - 1] != v) {
                                v1 = field1[w][q - 1];
                            }
                            if (field1[w + 1][q - 1] != v) {
                                v1 = field1[w][q - 1];
                            }
                        }
                        squareswithsameID2.clear();
                        FloodFill2(w, q - 1, field1, v1);

                        for (int arraylist = 0; arraylist < squareswithsameID.size(); arraylist++) {
                            if (squareswithsameID.get(arraylist)[1] + 1 < field1[0].length && (field1[squareswithsameID
                                    .get(arraylist)[0]][squareswithsameID.get(arraylist)[1] + 1] == -1
                                    || field1[squareswithsameID.get(arraylist)[0]][squareswithsameID.get(arraylist)[1]
                                            + 1] == v
                                    || field1[squareswithsameID.get(arraylist)[0]][squareswithsameID.get(arraylist)[1]
                                            + 1] == v1)) {
                                brojac2++;
                            }
                        }
                        for (int arraylist = 0; arraylist < squareswithsameID2.size(); arraylist++) {
                            if (squareswithsameID2.get(arraylist)[1] + 1 < field1[0].length
                                    && (field1[squareswithsameID2.get(arraylist)[0]][squareswithsameID2
                                            .get(arraylist)[1] + 1] == -1
                                            || field1[squareswithsameID2.get(arraylist)[0]][squareswithsameID2
                                                    .get(arraylist)[1] + 1] == v
                                            || field1[squareswithsameID2.get(arraylist)[0]][squareswithsameID2
                                                    .get(arraylist)[1] + 1] == v1)) {
                                brojac2++;
                            }
                        }

                        if (brojac2 == squareswithsameID2.size() + squareswithsameID.size()) {
                            for (int arraylist = 0; arraylist < squareswithsameID.size(); arraylist++) {
                                field1[squareswithsameID.get(arraylist)[0]][squareswithsameID.get(arraylist)[1]
                                        + 1] = v;
                                field1[squareswithsameID.get(arraylist)[0]][squareswithsameID.get(arraylist)[1]] = -1;
                            }
                            for (int arraylist = 0; arraylist < squareswithsameID2.size(); arraylist++) {
                                field1[squareswithsameID2.get(arraylist)[0]][squareswithsameID2.get(arraylist)[1]
                                        + 1] = v1;
                                if (field1[squareswithsameID2.get(arraylist)[0]][squareswithsameID2
                                        .get(arraylist)[1]] != v)
                                    field1[squareswithsameID2.get(arraylist)[0]][squareswithsameID2
                                            .get(arraylist)[1]] = -1;
                            }

                        }

                    }
                    if (brojac == squareswithsameID.size()) {
                        for (int arraylist = 0; arraylist < squareswithsameID.size(); arraylist++) {
                            field1[squareswithsameID.get(arraylist)[0]][squareswithsameID.get(arraylist)[1] + 1] = v;
                            field1[squareswithsameID.get(arraylist)[0]][squareswithsameID.get(arraylist)[1]] = -1;
                        }
                        backgroundfield = field1;
                        return true;
                    }
                }

            }
        }
        return false;
    }

    public static int[][] translating(int[][] g) {
        int[][] translated = new int[g.length][g[0].length];
        for (int q = 0; q < g.length; q++) {
            for (int w = 0; w < g[0].length; w++) {
                if (g[q][w] != -1) {
                    translated[q][w] = a.get(g[q][w]);
                } else {
                    translated[q][w] = -1;
                }
            }
        }
        return translated;
    }

    public static void printarray(int[][] array) {
        for (int a = 0; a < array[0].length; a++) {
            for (int b = 0; b < array.length; b++) {
                System.out.print(array[b][a] + " ");
            }
            System.out.println(" ");
        }
    }

    public static void moveLeft() {
        int[][] pieceToPlace2 = PentominoDatabase.data[x][p];
        if (m - 1 >= 0 && canPut(pieceToPlace2, x, m - 1, n, oldfield)) {             
            m--;
        }
    }

    public static void moveRight() {
        int[][] pieceToPlace2 = PentominoDatabase.data[x][p];
        if (m + 1 < oldfield.length && canPut(pieceToPlace2, x, m + 1, n, oldfield)) {
            m++;
        }
    }

    public static void rotate() {
        int[][] pieceToPlace2 = PentominoDatabase.data[x][(p + 1) % PentominoDatabase.data[x].length];
        while (m < 0 && !canPut(pieceToPlace2, x, m, n, oldfield)) {
            m--;
            if (m < 0 || m + pieceToPlace2[0].length >= 30) {
                break;
            }
        }
        if (canPut(pieceToPlace2, x, m, n, oldfield)) {
            p = (p + 1) % PentominoDatabase.data[x].length;
        }
    }

    public static void dropDownCompletely() {
        int[][] pieceToPlace2 = PentominoDatabase.data[x][p];
        while (canPut(pieceToPlace2, x, m, n + 1, oldfield) && canPut(pieceToPlace2, x, m, n, oldfield)) {
            n++;
        }
    }

}
