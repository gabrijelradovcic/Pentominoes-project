import javax.swing.*;
import java.awt.*;

public class Frame extends JFrame {
    Panel panel;
    public Frame(){
        //set the title
        this.setTitle("Pentris Game-03");
        //set the exit button as the close operation
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //set the size of the window
        this.setSize(720,560);
        //don't allow user change the size of the window
        this.setResizable(false);
        //set the location of the window
        //this.setLocation(150,75);
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screen = toolkit.getScreenSize();
        int distanceWidth = (screen.width - this.getWidth()) / 2;
        int distanceHeight = (screen.height - this.getHeight()) / 2 - 20;
        this.setLocation(distanceWidth, distanceHeight);

        //set the default panel
        this.panel = new Panel();
        this.setContentPane(panel);
        this.setVisible(true);
    }

   

}
