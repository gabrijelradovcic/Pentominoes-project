
import javax.swing.*;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.event.*;




public class noviUI extends JPanel implements ActionListener
{
    public static JFrame window;
    private int[][] state;
    private int size;
    private Image imgnext;
    private JLabel labelnext = new JLabel("");
    JLabel label4;
    String str = TetrisGame.fullscore+" ";
    int [][] pieceToPlace2 = PentominoDatabase.data[TetrisGame.x][TetrisGame.p];
    
    public noviUI(int x, int y, int _size)
    {
        

        size = _size;
        setPreferredSize(new Dimension(x * size+200, y * size));
        this.setLayout(null);

        //button left
        JButton playButton = new JButton("Left");
        playButton.setBounds(280, 550, 150, 30);
        playButton.addActionListener(this);
        playButton.setActionCommand("Left");
        add(playButton); 

        //button right
        JButton playButton1 = new JButton("Right");
        playButton1.setBounds(280, 590, 150, 30);
        playButton1.addActionListener(this);
        playButton1.setActionCommand("Right");
        add(playButton1);

        //button rotate
        JButton playButton2 = new JButton("Rotate");
        playButton2.setBounds(280, 630, 150, 30);
        playButton2.addActionListener(this);
        playButton2.setActionCommand("Rotate");
        add(playButton2);

        //button drop
        JButton playButton3 = new JButton("Space");
        playButton3.setBounds(280, 670, 150, 30);
        playButton3.addActionListener(this);
        playButton3.setActionCommand("Space");
        add(playButton3);

        //set strings
        //TODO 

        JLabel label1 = new JLabel("Controls");
        label1.setBounds(320,450,150,150);
        label1.setFont(new Font("Serif", Font.BOLD, 20));

        JLabel label2 = new JLabel("PENTRIS");
        label2.setFont(new Font("Serif", Font.BOLD, 30));
        label2.setBounds(300,-20,150,150);

        JLabel score = new JLabel("Score");
        score.setFont(new Font("Serif", Font.BOLD, 20));
        score.setBounds(320,150,150,150);
        add(score);

        JLabel nextpentomino = new JLabel("Next pentomino");
        nextpentomino.setFont(new Font("Serif", Font.BOLD, 20));
        nextpentomino.setBounds(280,260,150,150);
        add(nextpentomino);


        //set background pic
        //TODO change color to pic 
        JPanel panel = new JPanel();
        // panel.setBackground(Color.WHITE);
        // panel.setBounds(280,250,150,30);
        add(panel);

        //label 4?
        label4 = new JLabel(str);
        label4.setBounds(320,450,150,150);
        label4.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
        panel.add(label4);

        JLabel label = new JLabel("");
        Image img = new ImageIcon(this.getClass().getResource("tetris.png")).getImage();
        label.setIcon(new ImageIcon(img));
        label.setBounds(320,50,150,150);
        add(label);
        labelnext.setBounds(310,350,150,150);
        add(label);
        add(label1);
        add(label2);
        //set title
        window = new JFrame("Pentomino");
        
        //set exit button as the default close operation
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //allowed user change the position size of the window
        window.setResizable(true);

        

        window.add(this);
        window.pack();
        window.setVisible(true);
        //window.setFocusable(true);

        //the game grid
        state = new int[x][y];
        for (int i = 0; i < state.length; i++)
        {
            for (int j = 0; j < state[i].length; j++)
            {
                state[i][j] = -1;
            }
        }

        window.addKeyListener(new KeyListener() 
        {
            @Override
            public void keyTyped(KeyEvent evt) {}
    
            @Override
            public void keyPressed(KeyEvent evt) 
            {
                if(evt.getKeyCode() == KeyEvent.VK_LEFT)
                {
                    TetrisGame.moveLeft();
                }

                else if (evt.getKeyCode() == KeyEvent.VK_RIGHT) 
                {
                    TetrisGame.moveRight();
                }

                else if (evt.getKeyCode() == KeyEvent.VK_UP)
                {
                    TetrisGame.rotate();

                }
                else if (TetrisGame.n==TetrisGame.previousn && evt.getKeyCode() == KeyEvent.VK_SPACE )
                {
                    TetrisGame.dropDownCompletely();
                    
                }
                else if (evt.getKeyCode() == KeyEvent.VK_B){
                    TetrisGame.botplays = true;
                }
                else if (evt.getKeyCode() == KeyEvent.VK_H){
                    TetrisGame.botplays = false;;
                }
            }

            @Override
            public void keyReleased(KeyEvent evt) {}
        });
    }

    @Override
    public void actionPerformed(ActionEvent keyboard) {
         String action = keyboard.getActionCommand();

         if (action.equals("Left")) {
            TetrisGame.moveLeft();
         }
         if (action.equals("Right")) {
            TetrisGame.moveRight();
         }
         if (action.equals("Rotate")) {
            TetrisGame.rotate();
         }
         if (action.equals("Space")) {
            TetrisGame.rotate();
        }
    }


    public void paintComponent(Graphics g)
    {
        Graphics2D localGraphics2D = (Graphics2D) g;

        //SET color to the board
        localGraphics2D.setColor(Color.CYAN);
        localGraphics2D.fill(getVisibleRect());

        localGraphics2D.setColor(Color.CYAN);
        // for (int i = 0; i <= state.length; i++)
        // {
        //     localGraphics2D.drawLine(i * size, 0, i * size, state[0].length * size);
        // }
        // for (int i = 0; i <= state[0].length; i++)
        // {
        //     localGraphics2D.drawLine(0, i * size, state.length * size, i * size);
        // }

        for (int i = 0; i < state.length; i++)
        {
            for (int j = 0; j < state[0].length; j++)
            {
                //localGraphics2D.setColor(GetColorOfID(state[i][j]));
                Image SQUARD_IMAGE = new ImageIcon(ReGetColorofID(state[i][j])).getImage();
                g.drawImage(SQUARD_IMAGE, i * size, j * size, null);

                //draw the line
                localGraphics2D.fill(new Rectangle2D.Double(i * size + 1, j * size + 1, size - 1, size - 1));
            }
        }
    }

    // private Color GetColorOfID(int i)
    // {
    //     if(i==0) {return Color.BLUE;}
    //     else if(i==1) {return Color.ORANGE;}
    //     else if(i==2) {return Color.DARK_GRAY;}
    //     else if(i==3) {return Color.GREEN;}
    //     else if(i==4) {return Color.MAGENTA;}
    //     else if(i==5) {return Color.PINK;}
    //     else if(i==6) {return Color.RED;}
    //     else if(i==7) {return Color.YELLOW;}
    //     else if(i==8) {return new Color(0, 0, 0);}
    //     else if(i==9) {return new Color(0, 0, 100);}
    //     else if(i==10) {return new Color(100, 0,0);}
    //     else if(i==11) {return new Color(0, 100, 0);}
    //     else {return Color.WHITE;}
    // }

    private String ReGetColorofID(int i){
        if(i==0) {return "0.png";}
        else if(i==1) {return "1.png";}
        else if(i==2) {return "2.png";}
        else if(i==3) {return "3.png";}
        else if(i==4) {return "4.png";}
        else if(i==5) {return "5.png";}
        else if(i==6) {return "6.png";}
        else if(i==7) {return "7.png";}
        else if(i==8) {return "8.png";}
        else if(i==9) {return "9.png";}
        else if(i==10) {return "10.png";}
        else if(i==11) {return "3.png";}
        else return "11.png";
    }

    public void setState(int[][] _state)
    {
        for (int i = 0; i < state.length; i++)
        {
            for (int j = 0; j < state[i].length; j++)
            {
                state[i][j] = _state[i][j];
            }
        }
        refresh();
        repaint();
    }


    //next pent
    public static String getPicture(int a){
        String nextpicture = "";
        switch(TetrisGame.nextx){
            case 0:
                nextpicture="X.png";
                break;
            case 1:
                nextpicture="I.png";
                break;
            case 2:
                nextpicture="Z.png";
                break;
            case 3:
                nextpicture="T.png";
                break;
            case 4:
                nextpicture="U.png";
                break;
            case 5:
                nextpicture="V.png";
                break;
            case 6:
                nextpicture="W.png";
                break;
            case 7:
                nextpicture="Y.png";
                break;
            case 8:
                nextpicture="L.png";
                break;
            case 9:
                nextpicture="P.png";
                break;
            case 10:
                nextpicture="N.png";
                break;
            case 11:
                nextpicture="F.png";
                break;
        }
        return nextpicture;
    }
    public static void main(String[] args) {

        new noviUI(5,15,32);
    
    }
    public void refresh(){
        if(TetrisGame.nextx!=TetrisGame.x){
            remove(labelnext);
            imgnext = new ImageIcon(this.getClass().getResource(getPicture(TetrisGame.nextx))).getImage();
            labelnext.setIcon(new ImageIcon(imgnext));
            labelnext.setBounds(310,350,150,150);
        } 
        add(labelnext);
        str = TetrisGame.fullscore + " ";
        label4.setText(str);
    }


    
}

